1.0.2 / 2019-02-21
==================

  * Fix `res.writeHead` patch missing return value

1.0.1 / 2015-09-29
==================

  * perf: enable strict mode

1.0.0 / 2014-08-10
==================

  * Honor `res.statusCode` change in `listener`
  * Move to `jshttp` organization
  * Prevent `arguments`-related de-opt

0.0.0 / 2014-05-13
==================

  * Initial implementation
